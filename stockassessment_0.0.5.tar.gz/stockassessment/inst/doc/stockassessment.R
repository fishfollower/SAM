## ----setopts,echo=FALSE--------------------------------------------------
require("knitr")
opts_chunk$set(fig.width=5,fig.height=5,
               out.width="0.8\\textwidth",echo=TRUE)
Rver <- paste(R.version$major,R.version$minor,sep=".")
used.pkgs <- c("stockassessment")  

