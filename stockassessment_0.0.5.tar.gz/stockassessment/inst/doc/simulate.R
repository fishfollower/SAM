## ----setup, include=FALSE, message=FALSE---------------------------------
library(stockassessment)
library(parallel)#for parLapply
library(knitr)
knitr::opts_chunk$set(echo = TRUE, fig.width=7, cache=FALSE)

## ----data----------------------------------------------------------------
cn <- read.ices("nsher/cn.dat")
cw <- read.ices("nsher/cw.dat")
dw <- read.ices("nsher/dw.dat")
lf <- read.ices("nsher/lf.dat")
lw <- read.ices("nsher/lw.dat")
mo <- read.ices("nsher/mo.dat")
nm <- read.ices("nsher/nm.dat")
pf <- read.ices("nsher/pf.dat")
pm <- read.ices("nsher/pm.dat")
sw <- read.ices("nsher/sw.dat")
surveys <- read.ices("nsher/survey.dat")
dat <- setup.sam.data(surveys=surveys,
                    residual.fleet=cn, 
                    prop.mature=mo, 
                    stock.mean.weight=sw, 
                    catch.mean.weight=cw, 
                    dis.mean.weight=dw, 
                    land.mean.weight=lw,
                    prop.f=pf, 
                    prop.m=pm, 
                    natural.mortality=nm, 
                    land.frac=lf)


## ----conf----------------------------------------------------------------
conf <- defcon(dat)
conf$fbarRange <- c(2,6)
conf$corFlag <- 1
conf$keyLogFpar <- matrix(c(
-1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
-1,    0,    1,    2,    3,    4,    5,    6,   -1,
-1,    7,   -1,   -1,   -1,   -1,   -1,   -1,   -1,
 8,   -1,   -1,   -1,   -1,   -1,   -1,   -1,   -1), nrow=4, byrow=TRUE)

## ----par-----------------------------------------------------------------
par <- defpar(dat,conf)
par$logFpar <- rep(0,9)

## ----run, results='hide'-------------------------------------------------
fit <- sam.fit(dat, conf, par)

## ----sim-----------------------------------------------------------------
simdat <- simulate(fit, seed=1, nsim=1)[[1]]

## ----fitsim, results='hide'----------------------------------------------
simfit <- sam.fit(simdat, conf, par)
ssbplot(fit)
ssbplot(simfit, add=TRUE)
fbarplot(fit, partial=FALSE)
fbarplot(simfit, add=TRUE, partial=FALSE)
recplot(fit)
recplot(simfit, add=TRUE)

## ----parallel fitsims, results='hide'------------------------------------
simlist <- simulate(fit, seed=1, nsim=3)
no_cores <- detectCores() - 1 #how many cores can we use
if( no_cores>2 ) no_cores <- 2 # Cran check does not allow us to use more than two 
cl <- makeCluster(no_cores) #set up some number of nodes
clusterExport(cl, c("conf", "par")) #send these objects to each node
clusterEvalQ(cl, {library(stockassessment)}) #load the package to each node
simfitslist <- parLapply(cl, simlist, function(x){sam.fit(x, conf, par)}) #do sam.fit to each element of the list
stopCluster(cl) #shut it down

## ----multiplot-----------------------------------------------------------
ssbplot(fit, cicol="red")#the original data
trash <- lapply(simfitslist, function(x){ssbplot(x, add=TRUE)})
trash <- lapply(simfitslist, function(x){ssbplot(x, ci=FALSE, add=TRUE)})

